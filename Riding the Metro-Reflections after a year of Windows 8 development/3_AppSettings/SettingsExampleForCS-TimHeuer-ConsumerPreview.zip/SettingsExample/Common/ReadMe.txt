﻿The Common directory contains classes and XAML styles that simplify application development.

These are not merely convenient, but are required by most Visual Studio project and item templates.
Removing, renaming, or otherwise modifying the content of these files may result in a project that
does not build, or that will not build once additional pages are added.  If variations on these
classes or styles are desired it is recommended that you copy the content under a new name and
modify your private copy.
